package com.example.tp7_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
