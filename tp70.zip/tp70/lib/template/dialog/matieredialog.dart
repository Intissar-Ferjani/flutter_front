import 'package:flutter/material.dart';

import '../../entities/matiere.dart';

class MatiereDialog extends StatelessWidget {
  final Matiere? matiere;
  final void Function(Matiere) onSubmit;

  MatiereDialog({this.matiere, required this.onSubmit});

  final _formKey = GlobalKey<FormState>();
  final _nomController = TextEditingController();
  final _coefController = TextEditingController();
  final _nbHeuresController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    if (matiere != null) {
      _nomController.text = matiere!.nom;
      _coefController.text = matiere!.coef.toString();
      _nbHeuresController.text = matiere!.nbHeures.toString();
    }

    return AlertDialog(
      title: Text(matiere == null ? 'Add Matiere' : 'Edit Matiere'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: _nomController,
              decoration: InputDecoration(labelText: 'Nom'),
              validator: (value) {
                if (value == null || value.isEmpty) return 'Nom is required';
                return null;
              },
            ),
            TextFormField(
              controller: _coefController,
              decoration: InputDecoration(labelText: 'Coef'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || int.tryParse(value) == null)
                  return 'Coef must be a number';
                return null;
              },
            ),
            TextFormField(
              controller: _nbHeuresController,
              decoration: InputDecoration(labelText: 'Nb Heures'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || int.tryParse(value) == null)
                  return 'Nb Heures must be a number';
                return null;
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              final matiere = Matiere(
                code: this.matiere?.code,
                nom: _nomController.text,
                coef: int.parse(_coefController.text),
                nbHeures: int.parse(_nbHeuresController.text),
              );
              onSubmit(matiere);
              Navigator.pop(context);
            }
          },
          child: Text('Save'),
        ),
      ],
    );
  }
}
