import 'package:flutter/material.dart';

import '../entities/matiere.dart';
import '../service/matiereservice.dart';
import '../template/dialog/matieredialog.dart';

class MatiereScreen extends StatefulWidget {
  @override
  _MatiereScreenState createState() => _MatiereScreenState();
}

class _MatiereScreenState extends State<MatiereScreen> {
  final MatiereService service = MatiereService();
  late Future<List<Matiere>> matieres;

  @override
  void initState() {
    super.initState();
    matieres = service.getAllMatieres();
  }

  void refresh() {
    setState(() {
      matieres = service.getAllMatieres();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Matieres'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => MatiereDialog(
                  onSubmit: (matiere) async {
                    await service.addMatiere(matiere);
                    refresh();
                  },
                ),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Matiere>>(
        future: matieres,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final data = snapshot.data!;
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                final matiere = data[index];
                return ListTile(
                  title: Text(matiere.nom),
                  subtitle:
                      Text('Coef: ${matiere.coef}, Hours: ${matiere.nbHeures}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) => MatiereDialog(
                              matiere: matiere,
                              onSubmit: (updatedMatiere) async {
                                await service.updateMatiere(updatedMatiere);
                                refresh();
                              },
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () async {
                          await service.deleteMatiere(matiere.code!);
                          refresh();
                        },
                      ),
                    ],
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
