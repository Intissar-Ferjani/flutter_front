class Matiere {
  final int? code;
  final String nom;
  final int coef;
  final int nbHeures;

  Matiere(
      {this.code,
      required this.nom,
      required this.coef,
      required this.nbHeures});

  factory Matiere.fromJson(Map<String, dynamic> json) {
    return Matiere(
      code: json['code'],
      nom: json['nom'],
      coef: json['coef'],
      nbHeures: json['nbHeures'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'code': code,
      'nom': nom,
      'coef': coef,
      'nbHeures': nbHeures,
    };
  }
}
