import 'package:flutter/material.dart';
import 'package:tp7_test/screen/departementscreen.dart';
import 'package:tp7_test/screen/matierescreen.dart';

import 'screen/classscreen.dart';
import 'screen/formationscreen.dart';
import 'screen/login.dart';
import 'screen/studentsscreen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'School Management',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const Login(),
        '/students': (context) => StudentScreen(),
        '/class': (context) => const ClasseScreen(),
        '/formation': (context) => const FormationScreen(),
        '/departement': (context) => const DepartementScreen(),
        '/matiere': (context) =>
            MatiereScreen(), // Removed const since it is stateful
      },
    );
  }
}
