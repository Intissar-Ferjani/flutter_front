import 'dart:convert';

import 'package:http/http.dart' as http;

import '../entities/matiere.dart';

class MatiereService {
  final String baseUrl = 'http://your-server-url/matiere';

  Future<List<Matiere>> getAllMatieres() async {
    final response = await http.get(Uri.parse('$baseUrl/all'));
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => Matiere.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load matieres');
    }
  }

  Future<Matiere> getMatiereById(int id) async {
    final response = await http.get(Uri.parse('$baseUrl/get/$id'));
    if (response.statusCode == 200) {
      return Matiere.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load matiere');
    }
  }

  Future<void> addMatiere(Matiere matiere) async {
    final response = await http.post(
      Uri.parse('$baseUrl/add'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(matiere.toJson()),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to add matiere');
    }
  }

  Future<void> updateMatiere(Matiere matiere) async {
    final response = await http.put(
      Uri.parse('$baseUrl/update'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(matiere.toJson()),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to update matiere');
    }
  }

  Future<void> deleteMatiere(int id) async {
    final response = await http.delete(Uri.parse('$baseUrl/delete?id=$id'));
    if (response.statusCode != 200) {
      throw Exception('Failed to delete matiere');
    }
  }
}
